-- Bihar Online Bazaar starter schema. Run in Supabase SQL Editor as project owner.
create extension if not exists pgcrypto;
create type public.user_role as enum ('customer','vendor','admin');
create type public.order_status as enum ('pending','accepted','packed','out_for_delivery','delivered','cancelled');

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', phone text not null default '', address text not null default '',
 role public.user_role not null default 'customer', is_approved boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), vendor_id uuid not null references public.profiles(id) on delete restrict,
 name text not null, description text not null default '', category text not null default 'किराना',
 price numeric(10,2) not null check(price > 0), stock integer not null default 0 check(stock >= 0),
 image_url text, is_active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references public.profiles(id) on delete restrict,
 delivery_address text not null, note text not null default '', total numeric(12,2) not null check(total >= 0),
 status public.order_status not null default 'pending', created_at timestamptz not null default now()
);
create table if not exists public.order_items (
 id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid not null references public.products(id) on delete restrict,
 vendor_id uuid not null references public.profiles(id) on delete restrict,
 product_name text not null, unit_price numeric(10,2) not null check(unit_price > 0), quantity integer not null check(quantity > 0),
 created_at timestamptz not null default now()
);

-- New accounts are always customer by default. User metadata cannot choose a privileged role.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name,phone,address,role,is_approved)
 values(new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'phone',''), coalesce(new.raw_user_meta_data->>'address',''), 'customer', false)
 on conflict (id) do nothing;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;


-- SECURITY DEFINER helpers avoid recursive RLS checks when policies inspect roles.
create or replace function public.current_role() returns public.user_role
language sql stable security definer set search_path=public as $$
 select role from public.profiles where id=auth.uid() limit 1; $$;
create or replace function public.current_vendor_approved() returns boolean
language sql stable security definer set search_path=public as $$
 select coalesce((select role='vendor' and is_approved from public.profiles where id=auth.uid()),false); $$;
create or replace function public.current_is_admin() returns boolean
language sql stable security definer set search_path=public as $$
 select coalesce((select role='admin' from public.profiles where id=auth.uid()),false); $$;

-- Profiles: user reads/edits own non-privileged fields. Admin can read/update all profiles.
create policy "profiles select self or admin" on public.profiles for select to authenticated using (id=auth.uid() or public.current_is_admin());
create policy "profiles update own details" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and role=(select p.role from public.profiles p where p.id=auth.uid()) and is_approved=(select p.is_approved from public.profiles p where p.id=auth.uid()));
create policy "admin update profiles" on public.profiles for update to authenticated using (public.current_is_admin()) with check (public.current_is_admin());

-- Products: public can view active products; approved vendor manages own listings; admin manages all.
create policy "public read active products" on public.products for select using (is_active=true or public.current_is_admin());
create policy "approved vendor insert own product" on public.products for insert to authenticated with check (vendor_id=auth.uid() and public.current_vendor_approved());
create policy "vendor update own product" on public.products for update to authenticated using (vendor_id=auth.uid() and public.current_vendor_approved()) with check (vendor_id=auth.uid() and public.current_vendor_approved());
create policy "vendor delete own product" on public.products for delete to authenticated using (vendor_id=auth.uid() and public.current_vendor_approved());
create policy "admin manage products" on public.products for all to authenticated using (public.current_is_admin()) with check (public.current_is_admin());

-- Orders: customer sees/creates own; admin sees all. Starter UI computes total in browser; validate totals server-side before real payments.
create policy "customer read own orders" on public.orders for select to authenticated using (customer_id=auth.uid() or public.current_is_admin());
create policy "customer create own pending order" on public.orders for insert to authenticated with check (customer_id=auth.uid() and status='pending');
create policy "admin update orders" on public.orders for update to authenticated using (public.current_is_admin()) with check (public.current_is_admin());
create policy "vendor read orders containing own products" on public.orders for select to authenticated using (exists(select 1 from public.order_items oi join public.profiles me on me.id=auth.uid() where oi.order_id=orders.id and oi.vendor_id=auth.uid() and me.role='vendor' and me.is_approved=true));

create policy "customer insert own order items" on public.order_items for insert to authenticated with check (exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid() and o.status='pending') and exists(select 1 from public.products p where p.id=product_id and p.vendor_id=vendor_id and p.is_active=true and p.stock>=quantity));
create policy "customer read own order items" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid()) or public.current_is_admin() or (vendor_id=auth.uid() and public.current_vendor_approved()));

-- Storage bucket for product photos. Create bucket via Dashboard as public bucket named product-images.
-- Policy permits approved vendors to upload only into a folder named with their own auth user UUID.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('product-images','product-images',true,3145728,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
create policy "public view product images" on storage.objects for select using (bucket_id='product-images');
create policy "approved vendor upload own folder" on storage.objects for insert to authenticated with check (bucket_id='product-images' and (storage.foldername(name))[1]=auth.uid()::text and public.current_vendor_approved());
create policy "approved vendor update own folder" on storage.objects for update to authenticated using (bucket_id='product-images' and (storage.foldername(name))[1]=auth.uid()::text and public.current_vendor_approved()) with check (bucket_id='product-images' and (storage.foldername(name))[1]=auth.uid()::text);

-- IMPORTANT: after creating your own account, replace YOUR_EMAIL below with your actual email and run this once.
-- update public.profiles set role='admin', is_approved=true where id=(select id from auth.users where email='YOUR_EMAIL');
